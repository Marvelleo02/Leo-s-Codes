-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2022 at 04:16 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Admin', 'idowudavidmarvellous@gmail.com', 'marvelleo');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `short_desc` varchar(250) NOT NULL,
  `long_desc` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `short_desc`, `long_desc`) VALUES
(7, 'Traditional Dishes', 'This is a popular category in Nigeria', 'Enjoy and savour traditional dishes from various tribes in Nigeria. We got you covered on dishes from home, be you yoruba, igbo, hausa or from some other ethnic group in Nigeria. Nigerian dishes never run out of protein. Various meats such as beef, mutton, and chicken and different species of fish are often used to garnish it to your relish.These dishes will blow your taste buds!'),
(8, 'Intercontinental Dishes', 'Intercontinental dishes makek our resturant available to not just traditional lovers or Nigerians but also Non-Nigerians. ', 'Intercontinental dishes include dishes that can be and are eaten by people not just from Nigeria but from other places in Africa as well as the world. Dishes like Jollof Rice, Fried Rice are tastefully prepared here to give your taste buds a heavenly feel.'),
(9, 'Pastries And Grills', 'This includes our baked and grilled products specially made to blow your mind', 'Enjoy our well baked pastries and our grills.'),
(10, 'Soft Drinks And Fruit Drinks', 'Cool your system with our chilled carbonated and fresh drinks.', 'Need a cold glass of coke to go along with your food? Need a fanta? Whatever form of  chilled carbonted drink you want, we got you covered. We also have chilled fresh fruit drinks for you if you\'re not a fan of carbonated drinks.  '),
(11, 'Ice Cream', 'Sweet frozen food for your dessert', 'Ice creams of different flavours available for our beloved customers. One taste and you literally melt for the ice cream.'),
(12, 'Cakes', 'Cakes available in different flavours and sizes. Make that even special with a taste of our royal cakes.', 'Make that occassion special with a feel of royalty by getting our delicious royal cakes.');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `fname` varchar(500) NOT NULL,
  `description` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `cat_id`, `fname`, `description`) VALUES
(1, 7, 'Amala And Ewedu', 'NGN 4000'),
(2, 8, 'Spicy Jollof Rice With Spicy Grilled Chicken', 'NGN 3000'),
(3, 8, 'Spicy Fried Noodles With Egg', 'NGN 2500'),
(4, 8, 'Ghana Jollof With Grilled Tilapia', 'NGN 4000'),
(5, 9, 'Royal Grilled Chicken (Bucket Of Three)', 'NGN 3200'),
(6, 9, 'Royal Grilled Chicken ( Bucket Of Five)', 'NGN 4800'),
(7, 7, 'Pounded Yam And Egusi', 'NGN 5000'),
(8, 7, 'Eba And Ogbono', 'NGN 3500'),
(9, 7, 'Pounded Yam And Edikaikang', 'NGN 4000 '),
(10, 7, 'Eba And Oha Soup', 'NGN 3000'),
(11, 7, 'Goat Meat Pepper Soup', 'NGN 3000'),
(12, 10, 'Coke (250 ml)', 'NGN 300'),
(13, 10, 'Coke (1.25L)', 'NGN 1200'),
(14, 10, 'Chivita Active (125 ml)', 'NGN 700'),
(15, 10, 'Royal Orange Juice', 'NGN 500'),
(16, 11, 'Royal Double Treat Ice Cream (450 ml, Vanilla And Strawberry)', 'NGN 2000'),
(17, 11, 'Royal Vanilla Ice Cream (250 ml)', 'NGN 1000'),
(18, 12, 'Royal Double Deck Cake (Vanilla And Strawberry)', 'NGN 10000'),
(20, 12, 'Royal Vanilla Cake', 'NGN 5000'),
(21, 12, 'Royal Chocolate Cake', 'NGN 5500'),
(23, 11, 'Royal Milkshake (120 ml)', 'NGN 700'),
(24, 12, 'Royal Red Velvet Cake', 'NGN 5000'),
(28, 9, 'Royal Grilled Tilapia', 'NGN 2000 per piece'),
(30, 9, 'Royal Grilled Chicken (Bucket of 8)', 'NGN 10000'),
(40, 9, 'Royal Meatpie', 'NGN 700'),
(41, 9, 'Royal Chicken Pie', 'NGN 1000'),
(50, 9, 'Chicken Pepperoni Pizza ', 'NGN 7000'),
(52, 9, 'Meat Lovers Pizza (Chicken, Beef, Pork, Bacon, Sausage)', 'NGN 10000 '),
(53, 9, 'Margarita Pizza (Plain Cheese)', 'NGN 5000'),
(55, 9, 'Veggie Pizza (Green Onions, Pepper, Tomato, Cabbage, Lettuce)', 'NGN 6000');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `food_id` varchar(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `timestamp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `user_id`, `food_id`, `user_name`, `timestamp`) VALUES
(2, 'RSTGF38435', '1', '50', 'Glorious David', '27:12:2022 20:20:10pm'),
(3, 'RSTGF384345', '3', '1', 'Samuel Nathan', '24:12:2022 12:02:06pm'),
(4, 'RSTGF38476', '6', '53', 'Winner Bakare', '27:12:2022 18:50:35pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `timestamp` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `timestamp`) VALUES
(3, 'Elorm Tey', 'elormtey25@gmail.com', '12345', '06:08:2019 01:40:08am');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
