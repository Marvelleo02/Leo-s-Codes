-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2023 at 12:31 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mishtidb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Admin', 'admin@kingsmeals.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `short_desc` varchar(250) NOT NULL,
  `long_desc` varchar(500) NOT NULL,
  `images` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `short_desc`, `long_desc`, `images`) VALUES
(7, 'Traditional Dishes', 'This is a popular category in Nigeria', 'Enjoy and savour traditional dishes from various tribes in Nigeria. We got you covered on dishes from home, be you yoruba, igbo, hausa or from some other ethnic group in Nigeria. Nigerian dishes never run out of protein. Various meats such as beef, mutton, and chicken and different species of fish are often used to garnish it to your relish.These dishes will blow your taste buds!', './images/Buffet 1.jpg'),
(8, 'Intercontinental Dishes', 'Intercontinental dishes makek our resturant available to not just traditional lovers or Nigerians but also Non-Nigerians. ', 'Intercontinental dishes include dishes that can be and are eaten by people not just from Nigeria but from other places in Africa as well as the world. Dishes like Jollof Rice, Fried Rice are tastefully prepared here to give your taste buds a heavenly feel.', ''),
(9, 'Pastries And Grills', 'This includes our baked and grilled products specially made to blow your mind', 'Enjoy our well baked pastries and our grills.', './images/Buffet 3.jpg'),
(10, 'Soft Drinks And Fruit Drinks', 'Cool your system with our chilled carbonated and fresh drinks.', 'Need a cold glass of coke to go along with your food? Need a fanta? Whatever form of  chilled carbonted drink you want, we got you covered. We also have chilled fresh fruit drinks for you if you\'re not a fan of carbonated drinks.  ', './images/Buffet1.jpg'),
(11, 'Ice Cream', 'Sweet frozen food for your dessert', 'Ice creams of different flavours available for our beloved customers. One taste and you literally melt for the ice cream.', './images/Buffet2.jpg'),
(12, 'Cakes', 'Cakes available in different flavours and sizes. Make that even special with a taste of our royal cakes.', 'Make that occassion special with a feel of royalty by getting our delicious royal cakes.', './images/Buffet3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `fname` varchar(500) NOT NULL,
  `description` varchar(250) NOT NULL,
  `images` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `cat_id`, `fname`, `description`, `images`) VALUES
(1, 7, 'Amala And Ewedu With Cow Meat', 'NGN4000', ''),
(2, 7, 'Eba And Bitterleaf Soup With Goat Meat', 'NGN3500', ''),
(3, 7, 'Pounded Yam And Egusi With Chicken', 'NGN5000', ''),
(4, 8, 'Jollof Rce With Spicy Griled Chicken', 'NGN4000', ''),
(5, 8, 'Spicy Fried Noodles With Egg', 'NGN3000', ''),
(6, 8, 'Fried Rice And Grilled Turkey', 'NGN5000', ''),
(7, 9, 'Meat Lovers Pizza (Beef, Chicken, Sausage, Pork)', 'NGN8000', ''),
(8, 9, 'Bucket Of Chicken (Bucket Of 5) With Fries', 'NGN5000', ''),
(9, 9, 'Grilled Tilapia (Plate Of 3)', 'NGN4000', ''),
(10, 10, 'Coke (1.25L)', 'NGN1200', ''),
(11, 10, 'Chivita Active (125 ml)', 'NGN700', ''),
(12, 10, 'Royal Orange Juice', 'NGN1000', ''),
(13, 11, 'Royal Double Treat Ice Cream (450 ml, Vanilla And Strawberry)', 'NGN2000', ''),
(14, 11, 'Royal Vanilla Ice Cream (250 ml)', 'NGN1000', ''),
(15, 11, 'Royal Triple Treat Ice Cream (650 ml, Vanilla, Chocolate And Strawberry)', 'NGN4000', ''),
(16, 12, 'Royal Double Deck Cake (Vanilla And Strawberry)', 'NGN10000', ''),
(17, 12, 'Royal Vanilla Cake', 'NGN5000', ''),
(18, 12, 'Royal Triple Deck Cake (Vanilla, Chocolate And Strawberry)', 'NGN14000', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_id` varchar(20) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `food_id` varchar(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `timestamp` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_id`, `user_id`, `food_id`, `user_name`, `timestamp`) VALUES
(4, 'RSTGF750828', '4', '2', 'Marvel', '02:01:2023 06:36:58pm'),
(5, 'RSTGF842163', '11', '15', 'Marvel', '02:01:2023 08:26:54pm'),
(6, 'RSTGF964861', '11', '5', 'Marvel', '02:01:2023 08:36:31pm'),
(7, 'RSTGF302303', '11', '2', 'Marvel', '03:01:2023 03:16:40am');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `timestamp` varchar(100) DEFAULT NULL,
  `contact` text DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `payment` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `timestamp`, `contact`, `address`, `payment`) VALUES
(4, 'Marvel', 'idowudavidmarvellous@gmail.com', 'marvellous', '31:12:2022 04:32:59pm', '07081569224', 'Foreshore Zone Magodo', 'Cash'),
(5, 'David', 'daviddmarv@gmail.com', 'david', '02:01:2023 08:32:31pm', '0905667198', 'Akinola Estate Magodo', 'POS'),
(8, 'Peniel Bhill', 'bhill20@gmail.com', 'peniel', '02:01:2023 10:29:08pm', '09025643162', 'Omole Berger', 'POS'),
(9, 'Lollipop', 'lolly@gmail.com', 'lolly', '02:01:2023 11:13:31pm', '08059676898', 'Ikeja GRA', 'Bank Transfer'),
(10, 'mavy bee', 'marvybee23@gmail.com', 'marvybee', '03:01:2023 12:44:49am', '09023567898', 'Lekki Lagos', 'Bank Transfer'),
(11, 'Marvel  David', 'idmarvellous@gmail.com', '56671998', '03:01:2023 12:56:02am', '09123476890', 'Jakande Ikeja', 'POS');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
