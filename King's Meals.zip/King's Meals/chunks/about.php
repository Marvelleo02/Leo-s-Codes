<section class="fabout">
		<div class="section white center">
		      <div class="row container">
		        <h2 class="header">ABOUT</h2>
		        <p class="grey-text text-darken-3 lighten-3">King's Meals is a resturant located in Magodo, Lagos. We are a resturant that provides food worthy of royals to our customers and ensure our customer comfortability and satisfaction. Being the most adored fast service restaurant brand in West Africa has always been our goal. We want to challenge the status quo by offering our clients great, everyday inexpensive value meals in clean, cool restaurants with friendly staff as part of our "Taste More" attitude. </p>
				<a href="/King's Meals/about king's meals.php" class="waves-effect waves-light btn" style="background: #ee6e73 !important;">Read More &raquo;</a>
		      </div>
	</section>