<section class="fdes">
		<div class="section white center">
			<h2 class="header" style="padding:20px; padding-bottom: 30px;">Resturant For Royalty</h2>
		      <div class="row container center">
		        <div class="col center l8 s12">
		        	<p>Enjoy the best traditional and intercontinental cuisines as well as the best pastries and grills from our resturant. We provide an atmosphere comfortable for people of all nations, tribes and age providing even facilities to keep your kids entertained. Looking for a place to enjoy a woderful meal with your family? King's Meal is your place. Looking for a good resturant to serve your businness partners? King's Meals is your plug. For whatever occasion and scenerio regarding food, King's Meals' got you.</p>
		        </div>
		        <div class="col center l4 s12">
		        	<img height="300" width="auto" style="object-fit: contain;" src="images/17964.jpg" alt="">
		        </div>
		        
		      </div>
	</section>