<section class="fcarousel">
		<div class="carousel carousel-slider myslider">
	    <a class="carousel-item" href="#one!"><img src="images/Buffet 4.jpg"></a>
	    <a class="carousel-item" href="#two!"><img src="images/Buffet 3.jpg"></a>
	    <a class="carousel-item" href="#three!"><img src="images/Buffet 2.jpg"></a>
	    <a class="carousel-item" href="#four!"><img src="images/Buffet 1.jpg"></a>
	  </div>
  </section>