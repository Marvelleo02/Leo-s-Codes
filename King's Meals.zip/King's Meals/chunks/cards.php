<section class="fcards">
		<div class="row" style="padding-left: 50px; padding-right: 50px;">
			<div class="col s12 m12 l4" style="padding: 50px 5px;">
				<div class="card">
				    <div class="card-image waves-effect waves-block waves-light">
				      <img class="activator" src="images/Buffet 1.jpg">
				    </div>
				    <div class="card-content">
				      <span class="card-title activator grey-text text-darken-4">Traditional Dishes<i class="material-icons right">more_vert</i></span>
				      <div class="card-content">
			          <p>Wanna check out the mouth-watering Foods of this category ? Explore Now!</p>
			        </div>
				    </div>
				    <div class="card-reveal">
				      <span class="card-title grey-text text-darken-4">Traditional Dishes<i class="material-icons right">close</i></span>
				      <p>Enjoy and savour traditional dishes from various tribes in Nigeria. We got you covered on dishes from home, be you yoruba, igbo, hausa or from some other ethnic group in Nigeria. Nigerian dishes never run out of protein. Various meats such as beef, mutton, and chicken and different species of fish are often used to garnish it to your relish.These dishes will blow your taste buds!</p>
				    </div>
				  </div>
			</div>
			<div class="col s12 m12 l4" style="padding: 50px 5px;">
				<div class="card">
				    <div class="card-image waves-effect waves-block waves-light">
				      <img class="activator" src="images/Buffet 2.jpg">
				    </div>
				    <div class="card-content">
				      <span class="card-title activator grey-text text-darken-4">Intercontinental Dishes<i class="material-icons right">more_vert</i></span>
				      <div class="card-content">
			          <p>Wanna check out the mouth-watering foods of this category ? Explore Now!</p>
			        </div>
				    </div>
				    <div class="card-reveal">
				      <span class="card-title grey-text text-darken-4">Intercontinental Dishes<i class="material-icons right">close</i></span>
				      <p>Intercontinental dishes include dishes that can be and are eaten by people not just from Nigeria but from other places in Africa as well as the world. Dishes like Jollof Rice, Fried Rice are tastefully prepared here to give your taste buds a heavenly feel.</p>
				    </div>
				  </div>
			</div>
			<div class="col s12 m12 l4" style="padding: 50px 5px;">
				<div class="card">
				    <div class="card-image waves-effect waves-block waves-light">
				      <img class="activator" src="images/Buffet 3.jpg">
				    </div>
				    <div class="card-content">
				      <span class="card-title activator grey-text text-darken-4">Pastries And Grills<i class="material-icons right">more_vert</i></span>
				      <div class="card-content">
			          <p>Wanna check out the mouth-watering Foods of this category ? Explore Now!</p>
			        </div>
				    </div>
				    <div class="card-reveal">
				      <span class="card-title grey-text text-darken-4">Pastries And Grills <i class="material-icons right">close</i></span>
				      <p>Enjoy our well baked pastries and our grills.</p>
				    </div>
				  </div>
			</div>
		</div>
		<div class="row center" style="margin-bottom: 50px;">
			<div class="col s12">
				<a href="food-categories.php" class="waves-effect waves-light btn" style="background: #ee6e73 !important;">More Foods &raquo;</a>
			</div>
		</div>
	</section>