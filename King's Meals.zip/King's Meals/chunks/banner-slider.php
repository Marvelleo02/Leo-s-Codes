<section class="fslider">
		<div class="slider">
			<ul class="slides">
		    <li>
		    	<img src="images/banner3.jpg">
		    	<div class="caption center-align black-text">  
		        <h3 style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">King's Meals - Food For The Royals!</h3>  
		        <h5 class="light black-text text-lighten-3"><strong>Food that makes you feel like a king.</strong></h5>  
		      </div>  
		    </li>

		    <li>
		    	<img src="images/banner4.jpg">
		    	<div class="caption center-align black-text">  
		        <h3 style="font-size: 3rem !important; font-style: bold !important; font-family: 'Bree Serif', serif;">Quality food at your beckoning</h3>  
		        <h5 class="light black-text text-lighten-3"><strong>We deliver Quality</strong></h5>  
		      </div>  
		    </li>
		    </ul>
		   
	  </div>
	</section>