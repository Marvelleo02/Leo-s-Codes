<div id="modal1" class="modal">
    <div class="modal-content">
      <h4>About King's Meals</h4>
      <p>We are King's Meals. We aim and love to serve our customers delicious foods fit for royals. 
    <div class="modal-footer">
      <a href="#!" class="modal-close waves-effect waves-green btn-flat">Close</a>
    </div>
  </div>